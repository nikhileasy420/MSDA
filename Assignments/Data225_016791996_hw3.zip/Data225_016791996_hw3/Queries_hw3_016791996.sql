use employees;
#1. The most recently hired employee in each of the departments of the organization
select de.emp_no,de.dept_no,d.dept_name,e.first_name,last_name,from_date
 from dept_emp de
 inner join departments d on de.dept_no=d.dept_no
 inner join employees e on de.emp_no=e.emp_no
 where from_date in (select max(from_date) from dept_emp);
 
 #2 The number of distinct titles in every department;
 with main as (select title,de.emp_no,dept_name
 from dept_emp de
 left join titles t on de.emp_no = t.emp_no
 left join departments d on de.dept_no=d.dept_no)
 
 select dept_name,count(distinct title) as unique_titles,count(distinct emp_no) as employees
 from main
 group by dept_name;
 
 #3 The majority gender in each department
with main as (select de.dept_no,d.dept_name,e.gender,count(distinct de.emp_no) as employee_count
from dept_emp de
left join employees e on de.emp_no = e.emp_no
left join departments d on de.dept_no=d.dept_no
group by de.dept_no,d.dept_name,e.gender),

main2 as (select *,DENSE_RANK() OVER(PARTITION BY dept_no ORDER BY employee_count DESC) as gender_majority_rank
from main)

select * from main2
where gender_majority_rank=1;

#4 Employees who are making more than the average salary in their department
select emp_no,count(distinct salary) as salary_count
from salaries 
group by emp_no
order by count(distinct salary) desc;

#this means that an employee can have more than one salary across his tenure, 
#so we will only pickup the latest salary record across departments to understand the averages. 
with current_salaries as (select emp_no,salary,from_date,to_date, DENSE_RANK() OVER(ORDER BY from_date DESC) as salary_rank
from salaries),

main as (select de.dept_no,de.emp_no,salary,first_name,last_name,d.dept_name
from dept_emp de left join current_salaries cs on de.emp_no=cs.emp_no
left join employees e on de.emp_no=e.emp_no
left join departments d on de.dept_no=d.dept_no
where salary_rank=1),

dept_avg_salary as (select dept_name,avg(salary) as avg_salary
from dept_emp de left join current_salaries cs on de.emp_no=cs.emp_no
left join departments d on de.dept_no=d.dept_no
group by dept_name),

base as (select main.*,das.avg_salary from main left join dept_avg_salary das on main.dept_name=das.dept_name)
select * from (select emp_no,first_name,last_name,dept_name,salary,
(CASE WHEN salary < avg_salary THEN 0 else 1 end) as avg_salary_flag from base) a
where avg_salary_flag=1;

#5 The number of employees who have been working for less than two years in each department.

with main as(select de.emp_no,de.dept_no,d.dept_name,from_date,to_date,DATEDIFF(to_date,from_date) as duration_days
from dept_emp de
left join departments d on de.dept_no=d.dept_no)

select dept_name,count(distinct emp_no) as employee_count 
from main where duration_days < 730
group by dept_name
order by count(distinct emp_no) DESC;

#(6) Names of the employees (if any) who are drawing more than their managers.

with total_salaries as (select emp_no,sum(salary) as salary from salaries group by emp_no),

main as (select de.dept_no,de.emp_no,e.first_name,e.last_name,dm.emp_no as manager_no,
e2.first_name as manager_first_name,e2.last_name as manager_last_name,s.salary as employee_salary,s2.salary as manager_salary
from dept_emp de 
inner join dept_manager dm on de.dept_no=dm.dept_no
inner join employees e on de.emp_no=e.emp_no
inner join employees e2 on dm.emp_no=e.emp_no
inner join total_salaries s on de.emp_no=s.emp_no
inner join total_salaries s2 on dm.emp_no=s2.emp_no)

select concat(first_name," ",last_name) as employee_name
from main 
where employee_salary > manager_salary;

#checking the primary key for the dept_emp table from employees database
select emp_no,dept_no,count(*)
from dept_manager
group by emp_no,dept_no
having count(*) > 1;

#The number of employees who have been working for less than two years in each department.  
with max_hire_date as (select max(hire_date) as max_hire_date
from employees),

main as (select e.emp_no,concat(first_name," ",last_name) as full_name,hire_date,max_hire_date,d.dept_name
from employees e
left join max_hire_date on 1=1
left join dept_emp_view dev on e.emp_no=dev.emp_no
left join departments d on dev.dept_no=d.dept_no)

select dept_name,count(distinct emp_no) as employees_count
from (select emp_no,dept_name,datediff(max_hire_date,hire_date) as duration
from main) a where duration < 730
group by dept_name
order by count(distinct emp_no) desc;

#creating the views
create view dept_emp_view as 
select * from (select *,
DENSE_RANK() OVER(PARTITION BY emp_no order by from_date desc) as ranks
from dept_emp) a
where ranks = 1;

create view dept_manager_view as
select * from (select *,
DENSE_RANK() OVER(PARTITION BY dept_no order by from_date desc) as ranks
from dept_manager) a
where ranks = 1;

create view salaries_view as 
select * from (select *,
DENSE_RANK() OVER(PARTITION BY emp_no order by from_date desc) as ranks
from salaries) a
where ranks = 1;

#iv. Employees who are making more than the average salary in their department
with dept_avg_salary as (select dept_name,avg(salary) as avg_salary
from salaries_view sv left join dept_emp_view dev on sv.emp_no=dev.emp_no
left join departments d on dev.dept_no=d.dept_no
group by dept_name),

employees_salary as (select sv.emp_no,concat(first_name," ",last_name) as emp_name,sv.salary,d.dept_name
from salaries_view sv left join employees e on sv.emp_no=e.emp_no
left join dept_emp_view dev on sv.emp_no=dev.emp_no
left join departments d on dev.dept_no=d.dept_no),

main as (select es.*,avg_salary
from employees_salary es left join dept_avg_salary das on es.dept_name=das.dept_name)

select emp_no,emp_name,salary,dept_name,avg_salary as dept_avg_salary
from main where salary > avg_salary;

#greater than manager salary
with manager_salary as (select dmv.emp_no,concat(first_name," ",last_name) as emp_name, salary,dmv.dept_no
from dept_manager_view dmv 
left join salaries_view sv on dmv.emp_no=sv.emp_no
left join employees e on dmv.emp_no=e.emp_no),

employee_salary as (select dev.emp_no,concat(first_name," ",last_name) as emp_name, salary,dev.dept_no
from dept_emp_view dev left join salaries_view sv on dev.emp_no=sv.emp_no
left join employees e on dev.emp_no=e.emp_no),

main as (select es.*,ms.salary as manager_salary
from employee_salary es left join manager_salary ms on es.dept_no=ms.dept_no)

select main.*,dept_name
from main left join departments d on main.dept_no=d.dept_no where salary > manager_salary;

#highest salaries departments and manager
with dept_salaries as ( select dept_name,concat(first_name," ",last_name) as manager_name,sum(salary) as salary,
count(distinct dev.emp_no) as employees
from salaries_view sv
left join dept_emp_view dev on sv.emp_no=dev.emp_no
left join departments d on dev.dept_no=d.dept_no
left join dept_manager_view dmv on d.dept_no=dmv.dept_no
left join employees e on dmv.emp_no=e.emp_no
group by dept_name,concat(first_name," ",last_name))

select *,salary/employees as avg_salary_per_employee from dept_salaries
order by salary desc;
